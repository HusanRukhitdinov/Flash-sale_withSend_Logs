package logs

import (
	"api/config"
	"encoding/json"
	"net"
	"time"

	"github.com/sirupsen/logrus"
)

type JSONFormatter struct {
	ServiceName string
}

func (f *JSONFormatter) Format(entry *logrus.Entry) ([]byte, error) {
	logEntry := map[string]interface{}{
		"time":        entry.Time.Format(time.RFC3339),
		"level":       entry.Level.String(),
		"msg":         entry.Message,
		"serviceName": f.ServiceName,
	}

	serialized, err := json.Marshal(logEntry)
	if err != nil {
		return nil, err
	}

	return append(serialized, '\n'), nil
}

type TCPHook struct {
	Address string
	conn    net.Conn
}

func (hook *TCPHook) Fire(entry *logrus.Entry) error {
	if hook.conn == nil {
		var err error
		hook.conn, err = net.Dial("tcp", hook.Address)
		if err != nil {
			return err
		}
	}

	logMessage, err := entry.String()
	if err != nil {
		return err
	}

	_, err = hook.conn.Write([]byte(logMessage))
	return err
}

func (hook *TCPHook) Levels() []logrus.Level {
	return logrus.AllLevels
}

func InitLogger(cfg *config.Config) *logrus.Logger {
	logger := logrus.New()

	// JSON formatida log yozish uchun sozlash
	logger.SetFormatter(&JSONFormatter{ServiceName: cfg.SERVICE_NAME})

	// TCP Hook ni ulash
	tcpHook := &TCPHook{Address: "localhost:5000"}
	logger.AddHook(tcpHook)

	return logger
}
